<article class="post type-post status-publish format-gallery has-post-thumbnail hentry" >
    <div class="media-attachment">
        <div class="media-attachment-gallery">
            <div class=" ">
                <div class="item">
                    <figure>
                        <img width="1144" height="600" src="assets/images/blog/blog-1.jpg" class="attachment-post-thumbnail size-post-thumbnail" alt="1" />
                    </figure>
                </div><!-- /.item -->
            </div>
        </div><!-- /.media-attachment-gallery -->
    </div>

    <header class="entry-header">
        <h1 class="entry-title" itemprop="name headline">Robot Wars &#8211; Post with Gallery<span class="comments-link"><a href="#comments">Leave a comment</a></span></h1>

        <div class="entry-meta">
            <span class="cat-links"><a href="#" rel="category tag">Design</a>, <a href="#" rel="category tag">Technology</a></span>
            <span class="posted-on"><a href="#" rel="bookmark"><time class="entry-date published" datetime="2016-03-04T07:34:20+00:00">March 4, 2016</time> <time class="updated" datetime="2016-03-04T18:46:11+00:00" itemprop="datePublished">March 4, 2016</time></a></span>
        </div>
    </header><!-- .entry-header -->

    <div class="entry-content" itemprop="articleBody">
        <p class="highlight">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tincidunt, erat in malesuada aliquam, est erat faucibus purus, eget viverra nulla sem vitae neque. Quisque id sodales libero. In nec enim nisi, in ultricies quam. Sed lacinia feugiat velit, cursus molestie lectus mollis et.</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam quis diam erat. Duis velit lectus, posuere a blandit sit amet, tempor at lorem. Donec ultricies, lorem sed ultrices interdum, leo metus luctus sem, vel vulputate diam ipsum sed lorem. Donec tempor arcu nisl, et molestie massa scelerisque ut. Nunc at rutrum leo. Mauris metus mauris, tristique quis sapien eu, rutrum vulputate enim.</p>
        <p>Mauris tempus erat laoreet turpis lobortis, eu tincidunt erat fermentum. Aliquam non tincidunt urna. Integer tincidunt nec nisl vitae ullamcorper. Proin sed ultrices erat. Praesent varius ultrices massa at faucibus. Aenean dignissim, orci sed faucibus pharetra, dui mi dignissim tortor, sit amet condimentum mi ligula sit amet augue. Pellentesque vitae eros eget enim mollis placerat.</p>
        <div class="row">
            <div class="col-md-6">
                <p class="highlight-light">Mauris tempus erat laoreet turpis lobortis, eu tincidunt erat fermentum.</p>
                <p>Aliquam non tincidunt urna. Integer tincidunt nec nisl vitae ullamcorper. Proin sed ultrices erat. Praesent varius ultrices massa at faucibus. Aenean dignissim, orci sed faucibus pharetra, dui mi dignissim tortor, sit amet condimentum mi ligula sit amet augue. Pellentesque vitae eros eget enim mollis placerat.
                </p>
            </div>
            <div class="col-md-6">
                <blockquote><p>Pellentesque sodales augue eget ultricies ultricies. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur sagittis ultrices condimentum.</p>
                    <p>Pellentesque ullamcorper libero in enim pellentesque lobortis. Praesent ut dui ac metus iaculis scelerisque at eget metus.</p></blockquote>
                </div>
            </div>
        </div><!-- .entry-content -->
</article>
