<div id="content" class="site-content" tabindex="-1">
    <div class="container">
        <div id="primary" class="content-area">
            <main id="main" class="site-main">
                <?php require_once 'inc/blocks/homepage-3/home-v3-slider.php'; ?>
                <?php require_once 'inc/blocks/homepage-3/features-list.php'; ?>
                <?php require_once 'inc/blocks/homepage-3/home-v3-ads-block.php'; ?>
                <?php require_once 'inc/blocks/homepage-3/products-carousel-tabs.php'; ?>
                <?php require_once 'inc/blocks/homepage-3/products-carousel-with-image.php'; ?>
                <?php require_once 'inc/blocks/homepage-3/section-product-cards-carousel.php'; ?>
                <?php require_once 'inc/blocks/homepage-3/products-6-1.php'; ?>
                <?php require_once 'inc/blocks/homepage-3/home-list-categories.php'; ?>
            </main><!-- #main -->
        </div><!-- #primary -->
    </div><!-- .container -->
</div><!-- #content -->
