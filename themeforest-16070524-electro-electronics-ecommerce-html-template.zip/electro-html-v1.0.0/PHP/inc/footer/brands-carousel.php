<section class="brands-carousel">
	<h2 class="sr-only">Brands Carousel</h2>
	<div class="container">
		<div id="owl-brands" class="owl-brands owl-carousel unicase-owl-carousel owl-outer-nav">

			<div class="item">

				<a href="#">

					<figure>
						<figcaption class="text-overlay">
							<div class="info">
								<h4>Acer</h4>
							</div><!-- /.info -->
						</figcaption>

						 <img src="assets/images/brands/1.png" class="img-responsive" alt="">

					</figure>
				</a>
			</div><!-- /.item -->


			<div class="item">

				<a href="#">

					<figure>
						<figcaption class="text-overlay">
							<div class="info">
								<h4>Apple</h4>
							</div><!-- /.info -->
						</figcaption>

						 <img src="assets/images/brands/2.png" class="img-responsive" alt="">

					</figure>
				</a>
			</div><!-- /.item -->


			<div class="item">

				<a href="#">

					<figure>
						<figcaption class="text-overlay">
							<div class="info">
								<h4>Asus</h4>
							</div><!-- /.info -->
						</figcaption>

						 <img src="assets/images/brands/3.png" class="img-responsive" alt="">

					</figure>
				</a>
			</div><!-- /.item -->


			<div class="item">

				<a href="#">

					<figure>
						<figcaption class="text-overlay">
							<div class="info">
								<h4>Dell</h4>
							</div><!-- /.info -->
						</figcaption>

						<img src="assets/images/brands/4.png" class="img-responsive" alt="">

					</figure>
				</a>
			</div><!-- /.item -->


			<div class="item">

				<a href="#">

					<figure>
						<figcaption class="text-overlay">
							<div class="info">
								<h4>Gionee</h4>
							</div><!-- /.info -->
						</figcaption>

						<img src="assets/images/brands/5.png" class="img-responsive" alt="">

					</figure>
				</a>
			</div><!-- /.item -->


			<div class="item">

				<a href="#">

					<figure>
						<figcaption class="text-overlay">
							<div class="info">
								<h4>HP</h4>
							</div><!-- /.info -->
						</figcaption>

						<img src="assets/images/brands/6.png" class="img-responsive" alt="">

					</figure>
				</a>
			</div><!-- /.item -->


			<div class="item">

				<a href="#">

					<figure>
						<figcaption class="text-overlay">
							<div class="info">
								<h4>HTC</h4>
							</div><!-- /.info -->
						</figcaption>

						<img src="assets/images/brands/3.png" class="img-responsive" alt="">

					</figure>
				</a>
			</div><!-- /.item -->


			<div class="item">

				<a href="#">

					<figure>
						<figcaption class="text-overlay">
							<div class="info">
								<h4>IBM</h4>
							</div><!-- /.info -->
						</figcaption>

						<img src="assets/images/brands/5.png" class="img-responsive" alt="">

					</figure>
				</a>
			</div><!-- /.item -->


			<div class="item">

				<a href="#">

					<figure>
						<figcaption class="text-overlay">
							<div class="info">
								<h4>Lenova</h4>
							</div><!-- /.info -->
						</figcaption>

						<img src="assets/images/brands/2.png" class="img-responsive" alt="">

					</figure>
				</a>
			</div><!-- /.item -->


			<div class="item">

				<a href="#">

					<figure>
						<figcaption class="text-overlay">
							<div class="info">
								<h4>LG</h4>
							</div><!-- /.info -->
						</figcaption>

						<img src="assets/images/brands/1.png" class="img-responsive" alt="">

					</figure>
				</a>
			</div><!-- /.item -->


			<div class="item">

				<a href="#">

					<figure>
						<figcaption class="text-overlay">
							<div class="info">
								<h4>Micromax</h4>
							</div><!-- /.info -->
						</figcaption>

						<img src="assets/images/brands/6.png" class="img-responsive" alt="">

					</figure>
				</a>
			</div><!-- /.item -->


			<div class="item">

				<a href="#">

					<figure>
						<figcaption class="text-overlay">
							<div class="info">
								<h4>Microsoft</h4>
							</div><!-- /.info -->
						</figcaption>

						<img src="assets/images/brands/4.png" class="img-responsive" alt="">

					</figure>
				</a>
			</div><!-- /.item -->


		</div><!-- /.owl-carousel -->

	</div>
</section>

