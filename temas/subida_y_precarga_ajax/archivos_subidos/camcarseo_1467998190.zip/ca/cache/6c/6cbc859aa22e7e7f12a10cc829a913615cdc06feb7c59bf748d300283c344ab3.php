<?php

/* default/temp_menu.twig */
class __TwigTemplate_5f6835c5d50f30a96becfe6af54ea10053ed9e48f29e508cc4cd9c3d8d5db50d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<a class=\"home-link main-navigator-home-link no-print\" id=\"go-home-logo\">
                        <img alt=\"Logo\" class=\"logo no-print\" src=\"";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["host"]) ? $context["host"] : null), "html", null, true);
        echo "img/logos/logo_camcar.png\" alt=\"CAMCAR\">
                    </a>
                    <ul class=\"sf-menu navigation-bar no-print\" itemscope itemtype=\"http://schema.org/BreadcrumbList\">
                        <li itemprop=\"itemListElement\" itemscope itemtype=\"http://schema.org/ListItem\">
                            <a itemprop=\"item\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, (isset($context["host"]) ? $context["host"] : null), "html", null, true);
        echo "\" id=\"go-index\" class=\"cur-hover menu-toggle-close\">
                                <span itemprop=\"name\">Inicio</span>
                            </a>
                            <meta itemprop=\"position\" content=\"1\" />
                        </li>
                        <li itemprop=\"itemListElement\" itemscope itemtype=\"http://schema.org/ListItem\">
                            <a itemprop=\"item\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, (isset($context["host"]) ? $context["host"] : null), "html", null, true);
        echo "agencias/nuevos\" id=\"go-agencies-news\" class=\"cur-hover menu-toggle-close\">
                               <span itemprop=\"name\">Agencias</span> 
                            </a>
                            <meta itemprop=\"position\" content=\"2\" />
                        </li>
                        
                        <li class=\"has-dropdown\" itemprop=\"itemListElement\" itemscope itemtype=\"http://schema.org/ListItem\">
                            <a itemprop=\"item\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, (isset($context["host"]) ? $context["host"] : null), "html", null, true);
        echo "agencias/seminuevos\" id=\"dropdown-nav-preowuned\" class=\"cur-hover\">
                                <span itemprop=\"name\">Seminuevos</span>
                                 <meta itemprop=\"position\" content=\"3\" />
                            </a>
                            <ul class=\"subnav\">
                                <li ><a id=\"go-agencies-preowned\" href=\"";
        // line 24
        echo twig_escape_filter($this->env, (isset($context["host"]) ? $context["host"] : null), "html", null, true);
        echo "agencias/seminuevos\" class=\"cur-hover menu-toggle-close\">Agencias</a></li>
                                <li><a id=\"go-inventories-preowned\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, (isset($context["host"]) ? $context["host"] : null), "html", null, true);
        echo "seminuevos/inventarios\" class=\"cur-hover menu-toggle-close\">Inventarios</a></li>
                            </ul>
                        </li>
                        <li class=\"\" itemprop=\"itemListElement\" itemscope itemtype=\"http://schema.org/ListItem\">
                            <a itemprop=\"item\" href=\"";
        // line 29
        echo twig_escape_filter($this->env, (isset($context["host"]) ? $context["host"] : null), "html", null, true);
        echo "talleres\" id=\"go-workshop\" class=\"cur-hover menu-toggle-close\">
                                <span itemprop=\"name\">Talleres</span>
                                <meta itemprop=\"position\" content=\"4\" />
                            </a>
                        </li>
                        <li class=\"\" itemprop=\"itemListElement\" itemscope itemtype=\"http://schema.org/ListItem\">
                            <a itemprop=\"item\" href=\"";
        // line 35
        echo twig_escape_filter($this->env, (isset($context["host"]) ? $context["host"] : null), "html", null, true);
        echo "rentas\" id=\"go-rental\" class=\"cur-hover menu-toggle-close\" data-agencie-rental-name=\"U-SAVE Car &amp; Truck Rental\" data-agencie-rental-key=\"u-save-car-truck-rental\">
                                <span itemprop=\"name\">Rentas</span>
                                <meta itemprop=\"position\" content=\"5\" />
                            </a>
                        </li>
                        <li class=\"\" itemprop=\"itemListElement\" itemscope itemtype=\"http://schema.org/ListItem\">
                            <a itemprop=\"item\" href=\"";
        // line 41
        echo twig_escape_filter($this->env, (isset($context["host"]) ? $context["host"] : null), "html", null, true);
        echo "noticias\" id=\"go-blog\" class=\"cur-hover menu-toggle-close\">
                                <span itemprop=\"name\">Noticias</span>
                                <meta itemprop=\"position\" content=\"6\" />
                            </a>
                        </li>
                       
                        <li class=\"has-dropdown\" itemprop=\"itemListElement\" itemscope itemtype=\"http://schema.org/ListItem\">
                            <a itemprop=\"item\" href=\"";
        // line 48
        echo twig_escape_filter($this->env, (isset($context["host"]) ? $context["host"] : null), "html", null, true);
        echo "nosotros\" id=\"go-about-us\" class=\"cur-hover menu-toggle-close\">
                                <span itemprop=\"name\">Nosotros</span>
                                <meta itemprop=\"position\" content=\"7\" />
                            </a>
                            <ul class=\"subnav\">
                                <li><a id=\"go-job-opportunities\" class=\"cur-hover menu-toggle-close\">Bolsa de Trabajo</a></li>
                                <li><a id=\"go-contact\" href=\"contacto\" class=\"cur-hover menu-toggle-close\">Contacto</a></li>
                            </ul>
                        </li>
                        <li class=\"visible-sm visible-xs visible-xs-poeple\"><a href=\"";
        // line 57
        echo twig_escape_filter($this->env, (isset($context["host"]) ? $context["host"] : null), "html", null, true);
        echo "intranet/login/\" id=\"go-people-camcar-resp\" class=\"cur-hover\">Gente Camcar</a></li>
                    </ul>
                    <a href=\"";
        // line 59
        echo twig_escape_filter($this->env, (isset($context["host"]) ? $context["host"] : null), "html", null, true);
        echo "intranet/login/\" class=\"vin_people none-visible-xs hint-vin--bottom no-print\" data-vin-hint=\"GENTE CAMCAR\" id=\"sem-people-camcar\"><i class=\"fa fa-user no-print\"></i></a>";
    }

    public function getTemplateName()
    {
        return "default/temp_menu.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  112 => 59,  107 => 57,  95 => 48,  85 => 41,  76 => 35,  67 => 29,  60 => 25,  56 => 24,  48 => 19,  38 => 12,  29 => 6,  22 => 2,  19 => 1,);
    }
}
/* <a class="home-link main-navigator-home-link no-print" id="go-home-logo">*/
/*                         <img alt="Logo" class="logo no-print" src="{{host}}img/logos/logo_camcar.png" alt="CAMCAR">*/
/*                     </a>*/
/*                     <ul class="sf-menu navigation-bar no-print" itemscope itemtype="http://schema.org/BreadcrumbList">*/
/*                         <li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">*/
/*                             <a itemprop="item" href="{{host}}" id="go-index" class="cur-hover menu-toggle-close">*/
/*                                 <span itemprop="name">Inicio</span>*/
/*                             </a>*/
/*                             <meta itemprop="position" content="1" />*/
/*                         </li>*/
/*                         <li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">*/
/*                             <a itemprop="item" href="{{host}}agencias/nuevos" id="go-agencies-news" class="cur-hover menu-toggle-close">*/
/*                                <span itemprop="name">Agencias</span> */
/*                             </a>*/
/*                             <meta itemprop="position" content="2" />*/
/*                         </li>*/
/*                         */
/*                         <li class="has-dropdown" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">*/
/*                             <a itemprop="item" href="{{host}}agencias/seminuevos" id="dropdown-nav-preowuned" class="cur-hover">*/
/*                                 <span itemprop="name">Seminuevos</span>*/
/*                                  <meta itemprop="position" content="3" />*/
/*                             </a>*/
/*                             <ul class="subnav">*/
/*                                 <li ><a id="go-agencies-preowned" href="{{host}}agencias/seminuevos" class="cur-hover menu-toggle-close">Agencias</a></li>*/
/*                                 <li><a id="go-inventories-preowned" href="{{host}}seminuevos/inventarios" class="cur-hover menu-toggle-close">Inventarios</a></li>*/
/*                             </ul>*/
/*                         </li>*/
/*                         <li class="" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">*/
/*                             <a itemprop="item" href="{{host}}talleres" id="go-workshop" class="cur-hover menu-toggle-close">*/
/*                                 <span itemprop="name">Talleres</span>*/
/*                                 <meta itemprop="position" content="4" />*/
/*                             </a>*/
/*                         </li>*/
/*                         <li class="" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">*/
/*                             <a itemprop="item" href="{{host}}rentas" id="go-rental" class="cur-hover menu-toggle-close" data-agencie-rental-name="U-SAVE Car &amp; Truck Rental" data-agencie-rental-key="u-save-car-truck-rental">*/
/*                                 <span itemprop="name">Rentas</span>*/
/*                                 <meta itemprop="position" content="5" />*/
/*                             </a>*/
/*                         </li>*/
/*                         <li class="" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">*/
/*                             <a itemprop="item" href="{{host}}noticias" id="go-blog" class="cur-hover menu-toggle-close">*/
/*                                 <span itemprop="name">Noticias</span>*/
/*                                 <meta itemprop="position" content="6" />*/
/*                             </a>*/
/*                         </li>*/
/*                        */
/*                         <li class="has-dropdown" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">*/
/*                             <a itemprop="item" href="{{host}}nosotros" id="go-about-us" class="cur-hover menu-toggle-close">*/
/*                                 <span itemprop="name">Nosotros</span>*/
/*                                 <meta itemprop="position" content="7" />*/
/*                             </a>*/
/*                             <ul class="subnav">*/
/*                                 <li><a id="go-job-opportunities" class="cur-hover menu-toggle-close">Bolsa de Trabajo</a></li>*/
/*                                 <li><a id="go-contact" href="contacto" class="cur-hover menu-toggle-close">Contacto</a></li>*/
/*                             </ul>*/
/*                         </li>*/
/*                         <li class="visible-sm visible-xs visible-xs-poeple"><a href="{{host}}intranet/login/" id="go-people-camcar-resp" class="cur-hover">Gente Camcar</a></li>*/
/*                     </ul>*/
/*                     <a href="{{host}}intranet/login/" class="vin_people none-visible-xs hint-vin--bottom no-print" data-vin-hint="GENTE CAMCAR" id="sem-people-camcar"><i class="fa fa-user no-print"></i></a>*/
