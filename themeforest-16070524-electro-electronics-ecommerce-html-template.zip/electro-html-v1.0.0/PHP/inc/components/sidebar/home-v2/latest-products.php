<aside class="widget widget_products">
    <h3 class="widget-title">Latest Products</h3>
    <ul class="product_list_widget">
        <li>
            <a href="index.php?page=single-product" title="Notebook Black Spire V Nitro  VN7-591G">
                <img width="180" height="180" src="assets/images/product-category/1.jpg" alt="" class="wp-post-image"/><span class="product-title">Notebook Black Spire V Nitro  VN7-591G</span>
            </a>
            <span class="electro-price"><ins><span class="amount">&#36;1,999.00</span></ins> <del><span class="amount">&#36;2,299.00</span></del></span>
        </li>

        <li>
            <a href="index.php?page=single-product" title="Tablet Thin EliteBook  Revolve 810 G6">
                <img width="180" height="180" src="assets/images/product-category/2.jpg" alt="" class="wp-post-image"/><span class="product-title">Tablet Thin EliteBook  Revolve 810 G6</span>
            </a>
            <span class="electro-price"><span class="amount">&#36;1,300.00</span></span>
        </li>

        <li>
            <a href="index.php?page=single-product" title="Notebook Widescreen Z51-70  40K6013UPB">
                <img width="180" height="180" src="assets/images/product-category/3.jpg" alt="" class="wp-post-image"/><span class="product-title">Notebook Widescreen Z51-70  40K6013UPB</span>
            </a>
            <span class="electro-price"><span class="amount">&#36;1,100.00</span></span>
        </li>

        <li>
            <a href="index.php?page=single-product" title="Notebook Purple G952VX-T7008T">
                <img width="180" height="180" src="assets/images/product-category/4.jpg" alt="" class="wp-post-image"/><span class="product-title">Notebook Purple G952VX-T7008T</span>
            </a>
            <span class="electro-price"><span class="amount">&#36;2,780.00</span></span>
        </li>
    </ul>
</aside>
