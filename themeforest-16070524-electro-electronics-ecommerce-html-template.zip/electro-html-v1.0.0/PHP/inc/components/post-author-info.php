<div class="post-author-info">
	<div class="media">
		<div class="media-left media-middle">
			<a href="#"><img src="assets/images/blog/avatar.jpg" alt=""></a>
		</div>
		<div class="media-body">
			<h4 class="media-heading"><a href="#">Jane Smith</a></h4>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam quis diam erat. Duis velit lectus, posuere a blandit sit amet, tempor at lorem. Donec ultricies, lorem sed ultrices interdum, leo metus luctus sem, vel vulputate diam ipsum sed lorem.</p>
		</div>
	</div>
</div>
