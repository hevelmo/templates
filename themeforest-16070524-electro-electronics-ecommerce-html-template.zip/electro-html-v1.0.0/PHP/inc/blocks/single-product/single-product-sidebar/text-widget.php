<aside id="text-2" class="widget widget_text">			
	<div class="textwidget">
		<img src="assets/images/single-product/ad-banner.jpg" alt="Banner">
	</div><!-- .textwidget -->
</aside><!-- .widget -->