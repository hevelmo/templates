<nav class="navigation post-navigation">
	<h2 class="screen-reader-text">Post navigation</h2>
	<div class="nav-links"><div class="nav-previous"><a rel="prev" href="#"><span class="meta-nav">←</span>&nbsp;Robot Wars &ndash; Now Closed &ndash; Post with Audio</a></div></div>
</nav>
