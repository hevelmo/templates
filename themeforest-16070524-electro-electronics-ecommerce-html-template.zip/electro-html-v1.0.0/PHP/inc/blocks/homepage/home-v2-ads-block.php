<div class="home-v2-ads-block animate-in-view fadeIn animated" data-animation=" animated fadeIn">
    <div class="ads-block row">
        <div class="ad col-xs-12 col-sm-6">
            <div class="media">
                <div class="media-left media-middle"><img src="assets/images/ad-block/1.jpg" alt="" /></div>
                <div class="media-body media-middle">
                    <div class="ad-text">
                        Catch Big<br> <strong>Deals</strong>of the<br> Cameras
                    </div>
                    <div class="ad-action">
                        <a href="#">Shop now</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="ad col-xs-12 col-sm-6">
            <div class="media">
                <div class="media-left media-middle"><img src="assets/images/ad-block/2.jpg" alt="" /></div>
                <div class="media-body media-middle">
                    <div class="ad-text">
                        Tablets, <br>Smartphones<br> and more
                    </div>
                    <div class="ad-action">
                        <a href="#"><span class="from"><span class="prefix">From</span><span class="value"><sup>$</sup>74</span><span class="suffix">99</span></span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
