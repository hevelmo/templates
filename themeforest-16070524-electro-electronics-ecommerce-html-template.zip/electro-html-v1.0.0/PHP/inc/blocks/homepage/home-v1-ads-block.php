<div class="home-v1-ads-block animate-in-view fadeIn animated" data-animation="fadeIn">
	<div class="ads-block row">
		<div class="ad col-xs-12 col-sm-4">
			<div class="media">
				<div class="media-left media-middle">
					<img data-echo="assets/images/banner/cameras.jpg" src="assets/images/blank.gif" alt="">
				</div>
				<div class="media-body media-middle">
					<div class="ad-text">
						Catch Big <br><strong>Deals</strong> on the <br>Cameras						
					</div>
					<div class="ad-action">
						<a href="#">Shop now</a>
					</div>
				</div>
			</div>
		</div>

		<div class="ad col-xs-12 col-sm-4">
			<div class="media">
				<div class="media-left media-middle">
					<img data-echo="assets/images/banner/MobileDevicesv2-2.jpg" src="assets/images/blank.gif" alt="">
				</div>
				<div class="media-body media-middle">
					<div class="ad-text">
						Tablets,<br> Smartphones<br> <strong>and more</strong>
					</div>
					<div class="ad-action">
						<a href="#"><span class="upto"><span class="prefix">Upto</span><span class="value">70</span><span class="suffix"></span></span></a>
					</div>
				</div>
			</div>
		</div>

		<div class="ad col-xs-12 col-sm-4">
			<div class="media">
				<div class="media-left media-middle">
					<img data-echo="assets/images/banner/DesktopPC.jpg" src="assets/images/blank.gif" alt="">
				</div>
				<div class="media-body media-middle">
					<div class="ad-text">
						Shop the <br><strong>Hottest</strong><br> Products
					</div>
					<div class="ad-action">
						<a href="#">Shop now</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
