<?php

echo '<h1>Hola creatura</h1>';