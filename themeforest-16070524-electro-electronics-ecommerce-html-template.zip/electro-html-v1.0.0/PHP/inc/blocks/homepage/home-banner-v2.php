<div class="home-v2-banner-block animate-in-view fadeIn animated" data-animation=" animated fadeIn">
    <div class="home-v2-fullbanner-ad fullbanner-ad" style="margin-bottom: 70px">
        <a href="#">
            <img src="assets/images/banner/home-v2.png" class="img-fluid" alt="">
        </a>
    </div>
</div>
