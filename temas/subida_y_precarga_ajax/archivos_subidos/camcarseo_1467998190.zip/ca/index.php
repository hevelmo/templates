<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'core/vendor/autoload.php';
include 'core/environment/WaxConfigSet.php';

$container = new \Slim\Container(); 

$container['notFoundHandler'] = function ($c) {
    return function ($request, $response) use ($c) {

        return $c['response']
            ->withStatus(404)
            ->withHeader('Content-Type', 'text/html')
            ->write('No encontrado Handler');
    };
};



$app = new \Slim\App($container);




/*
      ___           ___           ___           ___     
     /\  \         /\  \         /\  \         /\  \    
    /::\  \       /::\  \       /::\  \       |::\  \   
   /:/\:\__\     /:/\:\  \     /:/\:\  \      |:|:\  \  
  /:/ /:/  /    /:/  \:\  \   /:/  \:\  \   __|:|\:\  \ 
 /:/_/:/__/___ /:/__/ \:\__\ /:/__/ \:\__\ /::::|_\:\__\
 \:\/:::::/  / \:\  \ /:/  / \:\  \ /:/  / \:\~~\  \/__/
  \::/~~/~~~~   \:\  /:/  /   \:\  /:/  /   \:\  \      
   \:\~~\        \:\/:/  /     \:\/:/  /     \:\  \     
    \:\__\        \::/  /       \::/  /       \:\__\    
     \/__/         \/__/         \/__/         \/__/    


    Url Principales
    Cuerpo del sitio web principal

*/

$app->get('/', 'CamcarControlClassApi:home');
$app->get('/agencias/nuevos[/{agencia_name}[/{agencia_url}[/{agn_id}]]]', 'CamcarControlClassApi:agencias');
$app->get('/agencias/seminuevos[/{agencia_name}[/{agencia_url}[/{agn_id}]]]', 'CamcarControlClassApi:agencias_seminuevos');

$app->get('/seminuevos/inventarios[/{marca}[/{modelo}[/{id_auto}]]]', 'CamcarControlClassApi:inventarios');

$app->get('/talleres', 'CamcarControlClassApi:talleres');
$app->get('/rentas[/{agencia_id}]', 'CamcarControlClassApi:rentas');

$app->get('/noticias[/{agencia}[/{blog}[/{id}]]]', 'CamcarControlClassApi:blog');

$app->get('/nosotros', 'CamcarControlClassApi:nosotros');
$app->get('/contacto', 'CamcarControlClassApi:contacto');
$app->get('/informacion', 'CamcarControlClassApi:informacion');
$app->get('/bolsa-de-trabajo', 'CamcarControlClassApi:bolsa');
$app->get('/aviso', 'CamcarControlClassApi:aviso');

/*
'/agencias/nuevos/:agn_name_agencia/:agn_url/:agn_id
/agencias/seminuevos/:preowned_agn_url/:preowned_agn_id

/seminuevos/inventarios/:mrcNombre/:mdoNombre/:senId'
/talleres
/rentas/:agnRental

/noticias/:blogAgencie/:blog/:blogId

/nosotros
/contacto
/informacion
/bolsa-de-trabajo
/aviso-de-privacidad
*/

$app->run();



/*
                    ___           ___           ___                       ___                         ___     
                   /\__\         /\  \         /\  \                     /\  \                       /\__\    
      ___         /:/ _/_       |::\  \       /::\  \                   /::\  \         ___         /:/ _/_   
     /\__\       /:/ /\__\      |:|:\  \     /:/\:\__\                 /:/\:\  \       /\__\       /:/ /\__\  
    /:/  /      /:/ /:/ _/_   __|:|\:\  \   /:/ /:/  /  ___     ___   /:/ /::\  \     /:/  /      /:/ /:/ _/_ 
   /:/__/      /:/_/:/ /\__\ /::::|_\:\__\ /:/_/:/  /  /\  \   /\__\ /:/_/:/\:\__\   /:/__/      /:/_/:/ /\__\
  /::\  \      \:\/:/ /:/  / \:\~~\  \/__/ \:\/:/  /   \:\  \ /:/  / \:\/:/  \/__/  /::\  \      \:\/:/ /:/  /
 /:/\:\  \      \::/_/:/  /   \:\  \        \::/__/     \:\  /:/  /   \::/__/      /:/\:\  \      \::/_/:/  / 
 \/__\:\  \      \:\/:/  /     \:\  \        \:\  \      \:\/:/  /     \:\  \      \/__\:\  \      \:\/:/  /  
      \:\__\      \::/  /       \:\__\        \:\__\      \::/  /       \:\__\          \:\__\      \::/  /   
       \/__/       \/__/         \/__/         \/__/       \/__/         \/__/           \/__/       \/__/    
    
    Definición de Templates
    Se utiliza Twig para entegrar los template definidos por el Room
    la administración se realiza con  CamcarControlClassApiSecure para procesos
    que requieren autenticación y CamcarControlClass para aquellos que no lo necesitan.
*/


class CamcarControlClassApiSecure {

  function __construct() {
      if (!isset($_SESSION['user_id'])) {
           Twig_Autoloader::register();

            $loader = new Twig_Loader_Filesystem('templates');
            $twig = new Twig_Environment($loader, array(
                        'cache' => 'cache',
                        'debug' => 'true'
                      ));
                     
            $twig->display('home.twig');
            exit();
      }
   }

  function inventarioRequest($request, $response, $args) {
    var_dump($args);
    //var_dump($request);
    echo 'Hola compañeros';
    $restore = new DataRequestInfoClass;
    $restore->multipliSecure($args);
    //var_dump($_SESSION['user_id']);
  }

  

  
}

class CamcarControlClassApi {
    public $masterConfigArray;

    function __construct($masterConfigArray){
        $this->masterConfigArray = array(
          'host' => HOST
        );
    }

    function home($request, $response, $args) {
     
      //var_dump($_SESSION['user_id']);
      Twig_Autoloader::register();

      $loader = new Twig_Loader_Filesystem('templates');
      $twig = new Twig_Environment($loader, array(
                  'cache' => 'cache',
                  'debug' => 'true'
                ));
               
      $twig->display('home.twig', $this->masterConfigArray);
    }

    function agencias($request, $response, $args) {
      //var_dump($this->masterConfigArray);
      //var_dump($_SESSION['user_id']);
      Twig_Autoloader::register();

      $loader = new Twig_Loader_Filesystem('templates');
      $twig = new Twig_Environment($loader, array(
                  'cache' => 'cache',
                  'debug' => 'true'
                ));
               
      $twig->display('distribuidor.twig', $this->masterConfigArray);
    }

    function agencias_seminuevos($request, $response, $args) {
      var_dump($args);
      //var_dump($_SESSION['user_id']);
      Twig_Autoloader::register();

      $loader = new Twig_Loader_Filesystem('templates');
      $twig = new Twig_Environment($loader, array(
                  'cache' => 'cache',
                  'debug' => 'true'
                ));
               
      $twig->display('distribuidor.twig', $this->masterConfigArray);
    }

    function inventarios($request, $response, $args) {
      var_dump($args);
      //var_dump($_SESSION['user_id']);
      Twig_Autoloader::register();

      $loader = new Twig_Loader_Filesystem('templates');
      $twig = new Twig_Environment($loader, array(
                  'cache' => 'cache',
                  'debug' => 'true'
                ));
               
      $twig->display('distribuidor.twig', $this->masterConfigArray);
    }

    function talleres($request, $response, $args) {
      var_dump($args);
      //var_dump($_SESSION['user_id']);
      Twig_Autoloader::register();

      $loader = new Twig_Loader_Filesystem('templates');
      $twig = new Twig_Environment($loader, array(
                  'cache' => 'cache',
                  'debug' => 'true'
                ));
               
      $twig->display('distribuidor.twig', $this->masterConfigArray);
    }

    function rentas($request, $response, $args) {
      var_dump($args);
      //var_dump($_SESSION['user_id']);
      Twig_Autoloader::register();

      $loader = new Twig_Loader_Filesystem('templates');
      $twig = new Twig_Environment($loader, array(
                  'cache' => 'cache',
                  'debug' => 'true'
                ));
               
      $twig->display('distribuidor.twig', $this->masterConfigArray);
    }

    function blog($request, $response, $args) {
      var_dump($args);
      //var_dump($_SESSION['user_id']);
      Twig_Autoloader::register();

      $loader = new Twig_Loader_Filesystem('templates');
      $twig = new Twig_Environment($loader, array(
                  'cache' => 'cache',
                  'debug' => 'true'
                ));
               
      $twig->display('distribuidor.twig', $this->masterConfigArray);
    }

    function nosotros($request, $response, $args) {
      var_dump($args);
      //var_dump($_SESSION['user_id']);
      Twig_Autoloader::register();

      $loader = new Twig_Loader_Filesystem('templates');
      $twig = new Twig_Environment($loader, array(
                  'cache' => 'cache',
                  'debug' => 'true'
                ));
               
      $twig->display('distribuidor.twig', $this->masterConfigArray);
    }

    function contacto($request, $response, $args) {
      var_dump($args);
      //var_dump($_SESSION['user_id']);
      Twig_Autoloader::register();

      $loader = new Twig_Loader_Filesystem('templates');
      $twig = new Twig_Environment($loader, array(
                  'cache' => 'cache',
                  'debug' => 'true'
                ));
               
      $twig->display('distribuidor.twig', $this->masterConfigArray);
    }

    function informacion($request, $response, $args) {
      var_dump($args);
      //var_dump($_SESSION['user_id']);
      Twig_Autoloader::register();

      $loader = new Twig_Loader_Filesystem('templates');
      $twig = new Twig_Environment($loader, array(
                  'cache' => 'cache',
                  'debug' => 'true'
                ));
               
      $twig->display('distribuidor.twig', $this->masterConfigArray);
    }

    function bolsa($request, $response, $args) {
      var_dump($args);
      //var_dump($_SESSION['user_id']);
      Twig_Autoloader::register();

      $loader = new Twig_Loader_Filesystem('templates');
      $twig = new Twig_Environment($loader, array(
                  'cache' => 'cache',
                  'debug' => 'true'
                ));
               
      $twig->display('distribuidor.twig', $this->masterConfigArray);
    }

    function aviso($request, $response, $args) {
      var_dump($args);
      //var_dump($_SESSION['user_id']);
      Twig_Autoloader::register();

      $loader = new Twig_Loader_Filesystem('templates');
      $twig = new Twig_Environment($loader, array(
                  'cache' => 'cache',
                  'debug' => 'true'
                ));
               
      $twig->display('distribuidor.twig', $this->masterConfigArray);
    }
}



/*
      ___           ___               
     /  /\         /  /\      ___     
    /  /::\       /  /::\    /  /\    
   /  /:/\:\     /  /:/\:\  /  /:/    
  /  /:/~/::\   /  /:/~/:/ /__/::\    
 /__/:/ /:/\:\ /__/:/ /:/  \__\/\:\__ 
 \  \:\/:/__\/ \  \:\/:/      \  \:\/\
  \  \::/       \  \::/        \__\::/
   \  \:\        \  \:\        /__/:/ 
    \  \:\        \  \:\       \__\/  
     \__\/         \__\/              
    
    Consultas API
    Procesos que se consumen vía DataRequestInfoClass
    se hace diferencia entre extends para URL seguras y las que no.
*/
class DataRequestInfoClass extends CamcarControlClassApiSecure{
    function multipliSecure($array_object) {
        $objData = (object) $array_object;
        
        echo '<br>';
        echo $objData->id;
   
    }
}


