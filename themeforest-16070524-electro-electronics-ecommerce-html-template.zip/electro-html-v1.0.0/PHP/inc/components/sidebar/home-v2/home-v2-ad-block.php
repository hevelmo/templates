<aside class="widget widget_text">
    <div class="textwidget">
        <a href="#">
        <img src="assets/images/banner/ad-banner-sidebar.jpg" alt="Banner"></a>
    </div>
</aside>
