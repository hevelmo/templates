<aside id="woocommerce_products-2" class="widget woocommerce widget_products">
	<h3 class="widget-title">Latest Products</h3>
	<ul class="product_list_widget">
		<li>
			<a href="index.php?page=single-product" title="Notebook Black Spire V Nitro  VN7-591G">
				<img class="wp-post-image" src="assets/images/products/2.jpg" alt="">		
				<span class="product-title">Notebook Black Spire V Nitro  VN7-591G</span>
			</a>
			<span class="electro-price"><ins><span class="amount">&#36;1,999.00</span></ins> <del><span class="amount">&#36;2,299.00</span></del></span>
		</li>

		<li>
			<a href="index.php?page=single-product" title="Tablet Thin EliteBook  Revolve 810 G6">
				<img class="wp-post-image" src="assets/images/products/5.jpg" alt="">	
				<span class="product-title">Tablet Thin EliteBook  Revolve 810 G6</span>
			</a>
			<span class="electro-price"><span class="amount">&#36;1,300.00</span></span>
		</li>

		<li>
			<a href="index.php?page=single-product" title="Notebook Widescreen Z51-70  40K6013UPB">
				<img class="wp-post-image" src="assets/images/products/6.jpg" alt="">		
				<span class="product-title">Notebook Widescreen Z51-70  40K6013UPB</span>
			</a>
			<span class="electro-price"><span class="amount">&#36;1,100.00</span></span>
		</li>

		<li>
			<a href="index.php?page=single-product" title="Notebook Purple G952VX-T7008T">
				<img class="wp-post-image" src="assets/images/products/1.jpg" alt="">	
				<span class="product-title">Notebook Purple G952VX-T7008T</span>
			</a>
			<span class="electro-price"><span class="amount">&#36;2,780.00</span></span>
		</li>

		<li>
			<a href="index.php?page=single-product" title="Laptop Yoga 21 80JH0035GE  W8.1 (Copy)">
				<img class="wp-post-image" src="assets/images/products/4.jpg" alt="">
				<span class="product-title">Laptop Yoga 21 80JH0035GE  W8.1 (Copy)</span>
			</a>
			<span class="electro-price"><span class="amount">&#36;3,485.00</span></span>
		</li>
	</ul><!-- .product_list_widget -->
</aside><!-- .widget -->