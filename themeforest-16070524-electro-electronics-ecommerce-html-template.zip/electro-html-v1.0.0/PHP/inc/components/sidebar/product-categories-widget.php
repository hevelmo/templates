<aside class="widget woocommerce widget_product_categories electro_widget_product_categories">
    <ul class="product-categories category-single">
        <li class="product_cat">
            <ul class="show-all-cat">
                <li class="product_cat"><span class="show-all-cat-dropdown">Show All Categories</span>
                    <ul>
                        <li class="cat-item"><a href="index.php?page=product-category">GPS &amp; Navi</a> <span class="count">(0)</span></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Home Entertainment</a> <span class="count">(1)</span></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Cameras &amp; Photography</a> <span class="count">(5)</span></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Smart Phones &amp; Tablets</a> <span class="count">(20)</span></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Video Games &amp; Consoles</a> <span class="count">(3)</span></li>
                        <li class="cat-item"><a href="index.php?page=product-category">TV &amp; Audio</a> <span class="count">(1)</span></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Gadgets</a> <span class="count">(3)</span></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Car Electronic &amp; GPS</a> <span class="count">(0)</span></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Accessories</a> <span class="count">(11)</span></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Printers &amp; Ink</a> <span class="count">(1)</span></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Software</a> <span class="count">(0)</span></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Office Supplies</a> <span class="count">(0)</span></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Computer Components</a> <span class="count">(1)</span></li>
                    </ul>
                </li>
            </ul>
            <ul>
                <li class="cat-item current-cat"><a href="index.php?page=product-category">Laptops &amp; Computers</a> <span class="count">(13)</span>
                    <ul class='children'>
                        <li class="cat-item"><a href="index.php?page=product-category">Laptops</a> <span class="count">(6)</span></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Ultrabooks</a> <span class="count">(1)</span></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Computers</a> <span class="count">(0)</span></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Mac Computers</a> <span class="count">(1)</span></li>
                        <li class="cat-item"><a href="index.php?page=product-category">All in One</a> <span class="count">(1)</span></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Servers</a> <span class="count">(1)</span></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Peripherals</a> <span class="count">(1)</span></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Gaming</a> <span class="count">(1)</span></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Accessories</a> <span class="count">(2)</span></li>
                    </ul>
                </li>
            </ul>
        </li>
    </ul>
</aside>
