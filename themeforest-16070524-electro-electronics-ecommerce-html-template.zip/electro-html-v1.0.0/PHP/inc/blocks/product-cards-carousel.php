<div class="product-cards-carousel">
    <ul class="products columns-2">
        <?php
            for( $i = 1; $i<=2; $i++ ) {
                display_product_cards();
            }
        ?>
    </ul>
</div>
