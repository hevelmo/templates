<div class="home-v3-features-block animate-in-view fadeIn animated" data-animation="fadeIn">
	<div class="features-list columns-5">
		<div class="feature">
			<div class="media">
				<div class="media-left media-middle feature-icon">
					<i class="ec ec-transport"></i>
				</div>
				<div class="media-body media-middle feature-text">
					<strong>Free Delivery</strong> from $50						
				</div>
			</div>
		</div><!-- .feature -->

		<div class="feature">
			<div class="media">
				<div class="media-left media-middle feature-icon">
					<i class="ec ec-customers"></i>
				</div>
				<div class="media-body media-middle feature-text">
					<strong>99% Positive</strong> Feedbacks						
				</div>
			</div>
		</div><!-- .feature -->

		<div class="feature">
			<div class="media">
				<div class="media-left media-middle feature-icon">
					<i class="ec ec-returning"></i>
				</div>
				<div class="media-body media-middle feature-text">
					<strong>365 days</strong> for free return						
				</div>
			</div>
		</div><!-- .feature -->

		<div class="feature">
			<div class="media">
				<div class="media-left media-middle feature-icon">
					<i class="ec ec-payment"></i>
				</div>
				<div class="media-body media-middle feature-text">
					<strong>Payment</strong> Secure System						
				</div>
			</div>
		</div><!-- .feature -->

		<div class="feature">
			<div class="media">
				<div class="media-left media-middle feature-icon">
					<i class="ec ec-tag"></i>
				</div>
				<div class="media-body media-middle feature-text">
					<strong>Only Best</strong> Brands						
				</div>
			</div>
		</div><!-- .feature -->
	</div><!-- .features-list -->
</div><!-- .home-v3-features-block -->