<section>
    <header>
        <h2 class="h1">Laptops &amp; Computers Categories</h2>
    </header>
    <div class="woocommerce columns-4">
        <ul class="product-loop-categories">
            <li class="product-category product first"><a href="index.php?page=cat-3-col"><img src="assets/images/product-category/7.jpg" alt="Accessories" width="250" height="232" /><h3>Accessories <mark class="count">(2)</mark></h3></a></li>
            <li class="product-category product"><a href="index.php?page=cat-3-col"><img src="assets/images/product-category/8.jpg" alt="All in One" width="250" height="232" /><h3>All in One <mark class="count">(1)</mark></h3></a></li>
            <li class="product-category product"><a href="index.php?page=cat-3-col"><img src="assets/images/product-category/9.jpg" alt="Gaming" width="250" height="232" /><h3>Gaming <mark class="count">(1)</mark></h3></a></li>
            <li class="product-category product last"><a href="index.php?page=cat-3-col"><img src="assets/images/product-category/10.jpg" alt="Laptops" width="250" height="232" /><h3>Laptops <mark class="count">(6)</mark></h3></a></li>
            <li class="product-category product first"><a href="index.php?page=cat-3-col"><img src="assets/images/product-category/11.jpg" alt="Mac Computers" width="250" height="232" /><h3>Mac Computers <mark class="count">(1)</mark></h3></a></li>
            <li class="product-category product"><a href="index.php?page=cat-3-col"><img src="assets/images/product-category/12.jpg" alt="Peripherals" width="250" height="232" /><h3>Peripherals <mark class="count">(1)</mark></h3></a></li>
            <li class="product-category product"><a href="index.php?page=cat-3-col"><img src="assets/images/product-category/13.jpg" alt="Servers" width="250" height="232" /><h3>Servers <mark class="count">(1)</mark></h3></a></li>
            <li class="product-category product last"><a href="index.php?page=cat-3-col"><img src="assets/images/product-category/14.jpg" alt="Ultrabooks" width="250" height="232" /><h3>Ultrabooks <mark class="count">(1)</mark></h3></a></li>
        </ul>
    </div>
</section>
