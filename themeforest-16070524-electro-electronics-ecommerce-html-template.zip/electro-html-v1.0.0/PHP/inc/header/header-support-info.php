<div class="header-support-info">
	<div class="media">
		<span class="media-left support-icon media-middle"><i class="ec ec-support"></i></span>
		<div class="media-body">
			<span class="support-number"><strong>Support</strong> (+800) 856 800 604</span><br/>
			<span class="support-email">Email: info@electro.com</span>
		</div>
	</div>
</div>
