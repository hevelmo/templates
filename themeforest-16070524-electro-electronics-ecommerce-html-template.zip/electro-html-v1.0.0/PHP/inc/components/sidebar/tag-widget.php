<aside id="tag_cloud-2" class="widget widget_tag_cloud"><h3 class="widget-title">Tags Clouds</h3>
    <div class="tagcloud">
        <a href='#' class='' title='10 topics' style='font-size: 22pt;'>amazon like</a>
        <a href='#' class='' title='10 topics' style='font-size: 22pt;'>Awesome</a>
        <a href='#' class='' title='10 topics' style='font-size: 22pt;'>bootstrap</a>
        <a href='#' class='' title='10 topics' style='font-size: 22pt;'>buy it</a>
        <a href='#' class='' title='10 topics' style='font-size: 22pt;'>clean design</a>
        <a href='#' class='' title='2 topics' style='font-size: 11.405405405405pt;'>electronics</a>
        <a href='#' class='' title='10 topics' style='font-size: 22pt;'>theme</a>
        <a href='#' class='' title='1 topic' style='font-size: 8pt;'>video post format</a>
        <a href='#' class='' title='10 topics' style='font-size: 22pt;'>woocommerce</a>
        <a href='#' class='' title='10 topics' style='font-size: 22pt;'>wordpress</a>
    </div>
</aside>
