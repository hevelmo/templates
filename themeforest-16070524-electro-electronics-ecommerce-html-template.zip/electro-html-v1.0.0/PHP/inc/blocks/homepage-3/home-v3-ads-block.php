<div class="home-v3-ads-block animate-in-view fadeIn animated" data-animation=" animated fadeIn">
	<div class="ads-block row">
		<div class="ad col-xs-12 col-sm-6">
			<div class="media">
				<div class="media-left media-middle">
					<img data-echo="assets/images/banner/cameras.jpg" src="assets/images/blank.gif" alt="">
				</div>
				<div class="media-body media-middle">
					<div class="ad-text">
						Catch Hottest <strong>Deals</strong> in Cameras Category						
					</div>
					<div class="ad-action">
						<a href="#">Shop now</a>
					</div>
				</div>
			</div>
		</div><!-- /.col -->
		
		<div class="ad col-xs-12 col-sm-6">
			<div class="media">
				<div class="media-left media-middle">
					<img data-echo="assets/images/banner/DesktopPC.jpg" src="assets/images/blank.gif" alt="">
				</div>
				<div class="media-body media-middle">
					<div class="ad-text">
						Tablets, Smartphones <br><strong>and more</strong>						
					</div>
					<div class="ad-action">
						<a href="#"><span class="from"><span class="prefix">From</span><span class="value"><sup>$</sup>749</span><span class="suffix">99</span></span></a>
					</div>
				</div>
			</div>
		</div><!-- /.col -->
	</div><!-- /.row -->
</div><!-- /.home-v3-ads-block -->