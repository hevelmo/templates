<nav class="navbar navbar-primary navbar-full yamm">
	<div class="container">
		<div class="clearfix">
			<button class="navbar-toggler hidden-sm-up pull-right flip" type="button" data-toggle="collapse" data-target="#header-v3">
				&#9776;
			</button>
		</div>

		<div class="collapse navbar-toggleable-xs" id="header-v3">
			<ul class="nav navbar-nav">
				<li class="menu-item 
				animate-dropdown"><a title="TV &amp; Audio" href="index.php?page=product-category">TV &#038; Audio</a></li>
				<li class="menu-item"><a title="RTV" href="index.php?page=product-category">RTV</a></li>
				<li class="menu-item"><a title="Computers" href="index.php?page=product-category">Computers</a></li>
				<li class="menu-item"><a title="Games &amp; Consoles" href="index.php?page=product-category">Games &#038; Consoles</a></li>
				<li class="menu-item"><a title="Gadgets" href="index.php?page=product-category">Gadgets</a></li>
				<li class="menu-item"><a title="Phones &amp; Tablets" href="index.php?page=product-category">Phones &#038; Tablets</a></li>
				<li class="menu-item"><a title="GPS &amp; Car Audio" href="index.php?page=product-category">GPS &#038; Car Audio</a></li>
				<li class="menu-item"><a title="Accessories" href="index.php?page=product-category">Accessories</a></li>
			</ul>				
		</div><!-- /.collpase -->
	</div><!-- /.-container -->
</nav><!-- /.navbar -->