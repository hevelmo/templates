<div class="shop-control-bar-bottom">
    <form class="form-electro-wc-ppp">
        <select class="electro-wc-wppp-select c-select" onchange="this.form.submit()" name="ppp"><option selected="selected" value="15">Show 15</option><option value="-1">Show All</option></select>
    </form>
    <p class="woocommerce-result-count">Showing 1&ndash;15 of 20 results</p>
    <nav class="woocommerce-pagination">
        <ul class="page-numbers">
            <li><span class="page-numbers current">1</span></li>
            <li><a href="#" class="page-numbers">2</a></li>
            <li><a href="#" class="next page-numbers">→</a></li>
        </ul>
    </nav>
</div>
