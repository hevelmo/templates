<div class="footer-newsletter">
	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-sm-7">
				<h5 class="newsletter-title">Sign up to Newsletter</h5>
				<span class="newsletter-marketing-text">...and receive <strong>$20 coupon for first shopping</strong></span>
			</div>
			<div class="col-xs-12 col-sm-5">
				<form>
					<div class="input-group">
						<input type="text" class="form-control" placeholder="Enter your email address">
						<span class="input-group-btn">
							<button class="btn btn-secondary" type="button">Sign Up</button>
						</span>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>