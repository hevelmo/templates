
<div class="home-v1-banner-block animate-in-view fadeIn animated" data-animation="fadeIn">

	<div class="home-v1-fullbanner-ad fullbanner-ad" style="margin-bottom: 70px">
		<a href="#">
			<img src="assets/images/blank.gif" data-echo="assets/images/banner/home-v1-banner.png" class="img-responsive" alt="">
			
		</a>
	</div>
</div><!-- /.home-v1-banner-block -->


