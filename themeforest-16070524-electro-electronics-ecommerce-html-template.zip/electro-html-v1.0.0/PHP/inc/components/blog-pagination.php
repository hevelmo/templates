<nav class="navigation pagination">
    <h2 class="screen-reader-text">Posts navigation</h2>
    <div class="nav-links">
        <ul class='page-numbers'>
            <li><span class='page-numbers current'>1</span></li>
            <li><a class='page-numbers' href='#'>2</a></li>
            <li><a class="next page-numbers" href="#">Next&nbsp;<span class="meta-nav">&rarr;</span></a></li>
        </ul>
    </div>
</nav>
