<aside class="widget widget_categories">
    <h3 class="widget-title">Categories</h3>
    <ul>
        <li class="cat-item"><a href="#" >Design</a></li>
        <li class="cat-item"><a href="#" >Events</a></li>
        <li class="cat-item"><a href="#" >Links &amp; Quotes</a></li>
        <li class="cat-item"><a href="#" >News</a></li>
        <li class="cat-item"><a href="#" >Social</a></li>
        <li class="cat-item"><a href="#" >Technology</a></li>
        <li class="cat-item"><a href="#" >Uncategorized</a></li>
        <li class="cat-item"><a href="#" >Videos</a></li>
	</ul>
</aside>
