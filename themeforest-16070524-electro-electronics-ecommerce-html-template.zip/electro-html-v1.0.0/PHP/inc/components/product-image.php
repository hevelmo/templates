<?php
$productImage = array(
	1 => array('product_image' => 'assets/images/products/1.jpg'),
	2 => array('product_image' => 'assets/images/products/2.jpg'),
	3 => array('product_image' => 'assets/images/products/3.jpg'),
	4 => array('product_image' => 'assets/images/products/4.jpg'),
	5 => array('product_image' => 'assets/images/products/5.jpg'),
	6 => array('product_image' => 'assets/images/products/6.jpg'),
	7 => array('product_image' => 'assets/images/products/4.jpg'),
	8 => array('product_image' => 'assets/images/products/2.jpg'),
	9 => array('product_image' => 'assets/images/products/5.jpg'),
	10 => array('product_image' => 'assets/images/products/1.jpg'),
	11 => array('product_image' => 'assets/images/products/6.jpg'),
	12 => array('product_image' => 'assets/images/products/3.jpg'),
	13 => array('product_image' => 'assets/images/products/5.jpg'),
	14 => array('product_image' => 'assets/images/products/4.jpg'),
	15 => array('product_image' => 'assets/images/products/2.jpg')
	);
?>
