<?php

echo '<h2> 404 </h2>';