<div class="electro-description">

	<h3>Perfectly Done</h3>
	<p>Praesent ornare, ex a interdum consectetur, lectus diam sodales elit, vitae egestas est enim ornare nisl. Nullam in lectus nec sem semper viverra. In lobortis egestas massa. Nam nec massa nisi. Suspendisse potenti. Quisque suscipit vulputate dui quis volutpat. Ut id elit facilisis, feugiat est in, tempus lacus. Ut ultrices dictum metus, a ultricies ex vulputate ac. Ut id cursus tellus, non tempor quam. Morbi porta diam nisi, id finibus nunc tincidunt eu.</p>
	<table class="layout">
		<tbody>
			<tr>
				<td>
					<h3>Wireless</h3>
					<p>Fusce vitae nibh mi. Integer posuere, libero et ullamcorper facilisis, enim eros tincidunt orci, eget vestibulum sapien nisi ut leo. Cras finibus vel est ut mollis. Donec luctus condimentum ante et euismod.</p>
					<h3>Fresh Design</h3>
					<p>Integer bibendum aliquet ipsum, in ultrices enim sodales sed. Quisque ut urna vitae lacus laoreet malesuada eu at massa. Pellentesque nibh augue, pellentesque nec dictum vel, pretium a arcu. Duis eu urna suscipit, lobortis elit quis, ullamcorper massa.</p>
					<h3>Fabolous Sound</h3>
					<p>Cras rutrum, nibh a sodales accumsan, elit sapien ultrices sapien, eget semper lectus ex congue elit. Nullam dui elit, fermentum a varius at, iaculis non dolor. In hac habitasse platea dictumst.
				</td>

				<td>
					<img class="alignright" data-echo="assets/images/single-product/ForDescription.jpg" src="assets/images/blank.gif" alt="">
					
				</td>
			</tr>
		</tbody>
	</table>

	<table class="layout">
		<tbody>
			<tr>
				<td>
					<img class="alignnone" data-echo="assets/images/single-product/ForDescription-1.png" src="assets/images/blank.gif" alt="">
				</td>
				
				<td>
					<h3 style="text-align: right;">Inteligent Bass</h3>
					<p style="text-align: right;">Fusce vitae nibh mi. Integer posuere, libero et ullamcorper facilisis, enim eros tincidunt orci, eget vestibulum sapien nisi ut leo. Cras finibus vel est ut mollis. Donec luctus condimentum ante et euismod.</p>
					<h3 style="text-align: right;">Battery Life</h3>
					<p style="text-align: right;">Integer bibendum aliquet ipsum, in ultrices enim sodales sed. Quisque ut urna vitae lacus laoreet malesuada eu at massa. Pellentesque nibh augue, pellentesque nec dictum vel, pretium a arcu. Duis eu urna suscipit, lobortis elit quis, ullamcorper massa.</p>
				</td>
			</tr>
		</tbody>
	</table>
</div><!-- /.electro-description -->

<div class="product_meta">
	<span class="sku_wrapper">SKU: <span class="sku" itemprop="sku">FW511948218</span></span>


	<span class="posted_in">Category:
		 <a href="index.php?page=product-category" rel="tag">Headphones</a>
	</span>

	<span class="tagged_as">Tags: 
		<a href="index.php?page=product-category" rel="tag">Fast</a>, 
		<a href="index.php?page=product-category" rel="tag">Gaming</a>, <a href="index.php?page=product-category" rel="tag">Strong</a>
	</span>

</div><!-- /.product_meta -->
