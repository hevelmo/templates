<nav>
	<ul id="menu-secondary-nav" class="secondary-nav">
		<li class="highlight menu-item"><a href="index.php?page=home-v2">Super Deals</a></li>
		<li class="menu-item"><a href="index.php?page=home-v3">Featured Brands</a></li>
		<li class="menu-item"><a href="index.php?page=home-v3-full-color-background">Trending Styles</a></li>
		<li class="menu-item"><a href="index.php?page=blog-v1">Gift Cards</a></li>
		<li class="pull-right menu-item"><a href="index.php?page=blog-v2">Free Shipping on Orders $50+</a></li>
	</ul>
</nav>
