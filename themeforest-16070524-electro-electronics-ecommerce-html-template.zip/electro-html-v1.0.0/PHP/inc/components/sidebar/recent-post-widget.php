<aside class="widget electro_recent_posts_widget"><h3 class="widget-title">Recent Posts</h3>
    <ul>
        <li>
            <a class="post-thumbnail" href="index.php?page=blog-single"><img width="150" height="150" src="assets/images/blog/blog-s-1.jpg" class="wp-post-image" alt="1"/></a>
            <div class="post-content">
                <a class ="post-name" href="index.php?page=blog-single">Robot Wars &#8211; Post with Gallery</a>
                <span class="post-date">March 4, 2016</span>
            </div>
        </li>
        <li>
            <a class="post-thumbnail" href="index.php?page=blog-single"><img width="150" height="150" src="assets/images/blog/blog-s-2.jpg" class="wp-post-image" alt="6" /></a>
            <div class="post-content">
                <a class ="post-name" href="index.php?page=blog-single">Robot Wars &#8211; Now Closed &#8211; Post with Audio</a>
                <span class="post-date">March 3, 2016</span>
            </div>
        </li>
        <li>
            <a class="post-thumbnail" href="index.php?page=blog-single"><img width="150" height="150" src="assets/images/blog/blog-s-3.jpg" class="wp-post-image" alt="video-format" /></a>
            <div class="post-content">
                <a class ="post-name" href="index.php?page=blog-single">Robot Wars &#8211; Now Closed &#8211; Post with Video</a>
                <span class="post-date">March 3, 2016</span>
            </div>
        </li>
        <li>
            <a class="post-thumbnail" href="index.php?page=blog-single"><div class="electro-img-placeholder"><img src="http://placehold.it/150x150/DDD/DDD/" alt=""><i class="fa fa-paragraph"></i></div></a>
            <div class="post-content">
                <a class ="post-name" href="index.php?page=blog-single">Announcement &#8211; Post without Image</a>
                <span class="post-date">March 2, 2016</span>
            </div>
        </li>
        <li>
            <a class="post-thumbnail" href="index.php?page=blog-single"><img width="150" height="150" src="assets/images/blog/blog-s-4.jpg" class="wp-post-image" alt="8"/></a>
            <div class="post-content">
                <a class ="post-name" href="index.php?page=blog-single">Robot Wars &#8211; Now Closed</a>
                <span class="post-date">March 1, 2016</span>
            </div>
        </li>
	</ul>
</aside>
