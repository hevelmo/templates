<div class="images electro-gallery">
	<div class="thumbnails-single owl-carousel">
		<a href="images/single-product/s1-1.jpg" class="zoom" title="" data-rel="prettyPhoto[product-gallery]">
			<img src="assets/images/blank.gif" data-echo="assets/images/single-product/s1-1.jpg" class="wp-post-image" alt="">
		</a>

		<a href="images/single-product/s1.jpg" class="zoom" title="" data-rel="prettyPhoto[product-gallery]">
			<img src="assets/images/blank.gif" data-echo="assets/images/single-product/s1.jpg" class="wp-post-image" alt="">
		</a>

		<a href="images/single-product/s2.jpg" class="zoom" title="" data-rel="prettyPhoto[product-gallery]">
			<img src="assets/images/blank.gif" data-echo="assets/images/single-product/s2.jpg" class="wp-post-image" alt="">
		</a>

		<a href="images/single-product/s3.jpg" class="zoom" title="" data-rel="prettyPhoto[product-gallery]">
			<img src="assets/images/blank.gif" data-echo="assets/images/single-product/s3.jpg" class="wp-post-image" alt="">
		</a>

		<a href="images/single-product/s4.jpg" class="zoom" title="" data-rel="prettyPhoto[product-gallery]">
			<img src="assets/images/blank.gif" data-echo="assets/images/single-product/s4.jpg" class="wp-post-image" alt="">
		</a>

		<a href="images/single-product/s5.jpg" class="zoom" title="" data-rel="prettyPhoto[product-gallery]">
			<img src="assets/images/blank.gif" data-echo="assets/images/single-product/s5.jpg" class="wp-post-image" alt="">
		</a>
	</div><!-- .thumbnails-single -->

	<div class="thumbnails-all columns-5 owl-carousel">
		<a href="images/single-product/single-thumb1.jpg" class="first" title="">
			<img src="assets/images/blank.gif" data-echo="assets/images/single-product/single-thumb1.jpg" class="wp-post-image" alt="">
		</a>

		<a href="images/single-product/single-thumb2.jpg" class="" title="">
			<img src="assets/images/blank.gif" data-echo="assets/images/single-product/single-thumb2.jpg" class="wp-post-image" alt="">
		</a>

		<a href="images/single-product/single-thumb3.jpg" class="" title="">
			<img src="assets/images/blank.gif" data-echo="assets/images/single-product/single-thumb3.jpg" class="wp-post-image" alt="">
		</a>

		<a href="images/single-product/single-thumb4.jpg" class="" title="">
			<img src="assets/images/blank.gif" data-echo="assets/images/single-product/single-thumb4.jpg" class="wp-post-image" alt="">
		</a>

		<a href="images/single-product/single-thumb5.jpg" class="last" title="">
			<img src="assets/images/blank.gif" data-echo="assets/images/single-product/single-thumb5.jpg" class="wp-post-image" alt="">
		</a>
		
		<a href="images/single-product/single-thumb6.jpg" class="first" title="">
			<img src="assets/images/blank.gif" data-echo="assets/images/single-product/single-thumb6.jpg" class="wp-post-image" alt="">
		</a>
	</div><!-- .thumbnails-all -->
</div><!-- .electro-gallery -->		